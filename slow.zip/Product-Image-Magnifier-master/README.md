# Product-Image-Magnifier
Product Image Magnifier using HTML, CSS, and JQuery
