package com.mesClasses;

public class DemandeT {
	String Matricule;
	String NbrPlaces;
	String idT;
	
	
	
	
	public String getIdT() {
		return idT;
	}
	public void setIdT(String idT) {
		this.idT = idT;
	}
	public String getMatricule() {
		return Matricule;
	}
	public void setMatricule(String matricule) {
		Matricule = matricule;
	}
	public String getNbrPlaces() {
		return NbrPlaces;
	}
	public void setNbrPlaces(String nbrPlaces) {
		NbrPlaces = nbrPlaces;
	}
	
	
	
	
	

	
}
