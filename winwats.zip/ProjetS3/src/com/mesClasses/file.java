package com.mesClasses;

public class file {
	String fichier;

	public String getFichier() {
		return fichier;
	}

	public void setFichier(String fichier) {
		this.fichier = fichier;
	}
	

}
