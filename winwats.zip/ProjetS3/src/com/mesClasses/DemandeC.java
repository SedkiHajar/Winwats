package com.mesClasses;

public class DemandeC {
	String nom;
	String prenom;
	String numTel;
	String idTC;
	
	
	
	
	public String getIdTC() {
		return idTC;
	}
	public void setIdTC(String idTC) {
		this.idTC = idTC;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getNumTel() {
		return numTel;
	}
	public void setNumTel(String numTel) {
		this.numTel = numTel;
	}
	

}
