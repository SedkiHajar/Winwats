package com.mesClasses;

import java.util.List;

public class DemandeE {
	String Id;
	String Nom;
	String  Prenom;
	String Poste;
	String Adresse;
	String Mail;
	String Shift;
	String idRespo;
	Float lat;
	Float lng;
	

	
	
	
	public Float getLat() {
		return lat;
	}
	public void setLat(Float lat) {
		this.lat = lat;
	}
	public Float getLng() {
		return lng;
	}
	public void setLng(Float lng) {
		this.lng = lng;
	}
	public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public String getIdRespo() {
		return idRespo;
	}
	public void setIdRespo(String idRespo) {
		this.idRespo = idRespo;
	}
	public String getNom() {
		return Nom;
	}
	public void setNom(String nom) {
		this.Nom = nom;
	}
	public String getPrenom() {
		return Prenom;
	}
	public void setPrenom(String prenom) {
		this.Prenom = prenom;
	}
	public String getPoste() {
		return Poste;
	}
	public void setPoste(String poste) {
		this.Poste = poste;
	}
	public String getAdresse() {
		return Adresse;
	}
	public void setAdresse(String adresse) {
		this.Adresse = adresse;
	}
	public String getMail() {
		return Mail;
	}
	public void setMail(String mail) {
		this.Mail = mail;
	}
	public String getShift() {
		return Shift;
	}
	public void setShift(String shift) {
		this.Shift = shift;
	}
	

}


